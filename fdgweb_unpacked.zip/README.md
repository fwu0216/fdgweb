# FDG Web (Unpacked)

这个项目已经是解压好的结构，上传到 GitHub 后能直接显示所有文件。

功能：
1. **F18-FDG 分装计算器**
2. **廊坊订药短信生成**

## 使用步骤
1. 上传整个 zip 到 GitHub（Add file → Upload files）
2. 提交后项目会显示 `app.py`, `templates/`, `static/` 等文件
3. 直接连接 Render 部署即可
